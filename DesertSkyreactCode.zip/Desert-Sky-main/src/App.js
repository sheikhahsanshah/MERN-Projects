import React from 'react';
import Sky from './Components/Sky';

function App() {
  return (
    <div className="App">
      <Sky />
    </div>
  );
}

export default App;
